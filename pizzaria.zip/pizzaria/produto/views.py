from django.shortcuts import render, redirect
from .models import Produto

# Create your views here.
def fproduto(request):
    produtos = Produto.objects.all()
    return render(request, "produto.html", {"produtos":produtos})

def salvarp(request):
    vnome = request.POST.get("nome")
    vpreco = request.POST.get("preco")
    vquantidade = request.POST.get("quantidade")
    if vnome:
        Produto.objects.create(nome=vnome, preco=vpreco, quantidade=vquantidade)
    produtos = Produto.objects.all()
    return render(request, "produto.html", {"produtos":produtos})

def deletep(request, id):
    produto = Produto.objects.get(id=id)
    produto.delete()
    return redirect(fproduto)


def exibirp(request, id):
    produto = Produto.objects.get(id=id)
    return render(request, "updatep.html", {"produto":produto})

def updatep(request, id):
    vnome = request.POST.get("nome")
    vpreco = request.POST.get("preco")
    vquantidade = request.POST.get("quantidade")
    produto = Produto.objects.get(id=id)
    produto.nome = vnome
    produto.preco = vpreco
    produto.quantidade = vquantidade
    produto.save()
    return redirect(fproduto)