from django.contrib import admin
from django.urls import path, include
from .views import fproduto, salvarp, deletep, exibirp, updatep

urlpatterns = [
    path('', fproduto),
    path('salvarp/', salvarp, name='salvarp'),
    path('deletep/<int:id>', deletep, name='deletep'),
    path('exibirp/<int:id>', exibirp, name='exibirp'),
    path('updatep/<int:id>', updatep, name='updatep'),
]